package com.example.soundcloudlyrics

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors

class MediaListener : NotificationListenerService() {
    private val worker = Executors.newSingleThreadExecutor()
    private var controller: MediaController? = null
    private var lastKey = ""
    private var syncedLyrics: List<Pair<Long, String>> = emptyList()
    private var trackTitle = "SoundCloud"
    private var artist = ""
    private var lastLine = ""
    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMetadata(metadata)
        }
        override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) {
            renderLine(state?.position ?: 0L)
        }
    }

    override fun onListenerConnected() {
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            val sound = sessions.firstOrNull {
                it.packageName.contains("soundcloud", ignoreCase = true)
            }
            if (sound != null) attach(sound) else update("SoundCloud", "Не найден активный трек")
        } catch (e: Exception) {
            update("SoundCloud", "Разреши доступ к уведомлениям и запусти музыку")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName.contains("soundcloud", ignoreCase = true)) {
            onListenerConnected()
        }
    }

    private fun attach(c: MediaController) {
        if (controller?.sessionToken == c.sessionToken) return
        controller?.unregisterCallback(callback)
        controller = c
        c.registerCallback(callback)
        readMetadata(c.metadata)
        renderLine(c.playbackState?.position ?: 0L)
    }

    private fun readMetadata(m: MediaMetadata?) {
        if (m == null) return
        trackTitle = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown track"
        artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val key = "$trackTitle|$artist"
        if (key != lastKey) {
            lastKey = key
            syncedLyrics = emptyList()
            update("$trackTitle · $artist", "Ищу синхронизированный текст…")
            worker.execute { fetchLyrics(trackTitle, artist) }
        }
    }

    private fun fetchLyrics(title: String, artist: String) {
        try {
            val q = "track_name=${enc(title)}&artist_name=${enc(artist)}"
            val conn = URL("https://lrclib.net/api/get?$q").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "LyricsWidget/1.0")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(body)
            val synced = json.optString("syncedLyrics", "")
            val parsed = synced.lines().mapNotNull { line ->
                val match = Regex("^\\[(\\d{2}):(\\d{2})(?:\\.(\\d{2,3}))?\\](.*)$").find(line) ?: return@mapNotNull null
                val mins = match.groupValues[1].toLong()
                val secs = match.groupValues[2].toLong()
                val frac = match.groupValues[3].let { if (it.isBlank()) 0L else it.toLong() * if (it.length == 2) 10 else 1 }
                (mins * 60000 + secs * 1000 + frac) to match.groupValues[4].trim()
            }.sortedBy { it.first }
            syncedLyrics = parsed
            if (parsed.isEmpty()) update("$title · $artist", "Синхронизированный текст не найден")
            renderLine(controller?.playbackState?.position ?: 0L)
        } catch (e: Exception) {
            update("$title · $artist", "Не удалось загрузить текст")
            Log.w("LyricsWidget", "LRCLIB request failed", e)
        }
    }

    private fun renderLine(position: Long) {
        val current = syncedLyrics.lastOrNull { it.first <= position }?.second
        if (current != null && current != lastLine) {
            lastLine = current
            update("$trackTitle · $artist", current)
        }
    }

    private fun update(song: String, line: String) {
        getSharedPreferences("lyrics", Context.MODE_PRIVATE).edit()
            .putString("song", song).putString("line", line).apply()
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, LyricsWidget::class.java))
        for (id in ids) {
            val views = RemoteViews(packageName, R.layout.widget_lyrics)
            views.setTextViewText(R.id.song, song)
            views.setTextViewText(R.id.line, line)
            manager.updateAppWidget(id, views)
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    override fun onDestroy() {
        controller?.unregisterCallback(callback)
        worker.shutdownNow()
        super.onDestroy()
    }
}
