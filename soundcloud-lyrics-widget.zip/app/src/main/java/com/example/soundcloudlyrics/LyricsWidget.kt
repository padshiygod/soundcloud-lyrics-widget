package com.example.soundcloudlyrics

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class LyricsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("lyrics", Context.MODE_PRIVATE)
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_lyrics)
            views.setTextViewText(R.id.song, prefs.getString("song", "SoundCloud · ожидание трека"))
            views.setTextViewText(R.id.line, prefs.getString("line", "Включи песню и разреши доступ к уведомлениям"))
            manager.updateAppWidget(id, views)
        }
    }
}
