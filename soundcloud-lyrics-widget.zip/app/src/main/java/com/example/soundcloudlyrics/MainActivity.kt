package com.example.soundcloudlyrics

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(0xFF000000.toInt())
        }
        layout.addView(TextView(this).apply {
            text = "Lyrics Widget"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
        })
        layout.addView(TextView(this).apply {
            text = "1. Разреши доступ к уведомлениям ниже.\n2. Вернись на главный экран и добавь виджет Lyrics Widget.\n3. Запусти SoundCloud. Если плеер публикует медиа-сессию, виджет попробует найти синхронизированный текст в LRCLIB.\n\nВажно: первая версия — экспериментальная; совместимость с модифицированным SoundCloud не гарантируется."
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 24, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "Разрешить доступ к уведомлениям"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        setContentView(layout)
    }
}
